* Create a project with following dependencies   

			1. Spring Cloud OAUTH2
			2. Spring Cloud web
			3. Spring Cloud Security
			4. Thymeleaf

* Create a controller named ReportController 
* Create home.html file in template folder 
* Refer to application.yml file